public class HelloWorld {

	public static void main(String[] args) {
		// System.out.println("Hello World");

		Pessoa p = new Pessoa("Andrew");
		System.out.println(p.getName());
	}

}
